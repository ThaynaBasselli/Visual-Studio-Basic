﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer3
{
    class Program
    {
        static void Main(string[] args)
        {
            // em uma variável B. A seguir (utilizando apenas atribuições entre variáveis) troque os seus conteúdos
            //  fazendo com que o valor que está em A passe para B e vice-versa. Ao final, escrever os valores que 
            // ficaram armazenados nas variáveis.
            int a, b, c;
            a = 10;
            b = 20;
            c = a;
            a = b;
            b = c;
            Console.Write(a + " ");
            Console.Write(b);
            Console.Read();
        }
    }
}
