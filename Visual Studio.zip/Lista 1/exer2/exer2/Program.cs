﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer2
{
    class Program
    {
        static void Main(string[] args)
        {
            float nt1, nt2, nt3, md;
            Console.Write("entre com a primeira nota :  ");
            nt1 = float.Parse(Console.ReadLine());
            Console.Write("entre com a segunda nota :  ");
            nt2 = float.Parse(Console.ReadLine());
            Console.Write("entre com a terceira nota :  ");
            nt3 = float.Parse(Console.ReadLine());
            md = (nt1 + nt2 + nt3) / 3;
            Console.Write("A média do aluno é :  " + md);
            Console.ReadLine();

        }
    }
}
