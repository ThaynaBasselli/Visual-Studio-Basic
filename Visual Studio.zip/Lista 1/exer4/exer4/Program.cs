﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer4
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exercicio 4 - Lista 1 - Escreva um algoritmo para ler um valor e escrever o seu antecessor.
            int x;
            Console.Write("digite um valor :");
            x = int.Parse(Console.ReadLine());
            x = x - 1;
            Console.WriteLine("o seu antecessor é :" + x);
            Console.Read();

        }
    }
}
