﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sucessor_e_antecessor
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;
            int a1, a2;
            string nome;

            Console.Write("Digite seu nome: ");
            nome = Console.ReadLine();
            Console.WriteLine("Olá, " + nome);
            Console.Write("Digite um número: ");
            a = Console.ReadLine();
            a1 = int.Parse(a) - 1;
            Console.Write("O número antecessor é:" + a1);
            Console.ReadLine();
            a2 = int.Parse(a) + 1;
            Console.Write("O número sucessor é:" + a2);
            Console.ReadLine();
        }
    }
}
