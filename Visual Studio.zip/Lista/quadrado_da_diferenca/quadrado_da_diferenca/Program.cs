﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quadrado_da_diferenca
{
    class Program
    {
        static void Main(string[] args)
        {
            string a, b;
            int c, d;
            string nome;
        
            Console.Write("Digite seu nome: ");
            nome = Console.ReadLine();
            Console.WriteLine("Olá, " + nome);
            Console.Write("Digite um número: ");
            a = Console.ReadLine();
            Console.Write("Digite outro número: ");
            b = Console.ReadLine();
            c = int.Parse(a) - int.Parse(b);
            d = c * c;
            Console.Write("O quadrado da diferença é: " + d);
            Console.ReadLine();
        }
    }
}
