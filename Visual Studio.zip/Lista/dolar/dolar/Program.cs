﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dolar
{
    class Program
    {
        static void Main(string[] args)
        {
            float cotacao, totalDolar, valorReais;
            Console.WriteLine("Conversor real ");
            Console.WriteLine();
            Console.WriteLine("Informe o valor do dólar hoje: ");
            cotacao = float.Parse(Console.ReadLine());
            Console.WriteLine("Total dólares do usuários: ");
            totalDolar = float.Parse(Console.ReadLine());
            valorReais = totalDolar / cotacao;
            Console.WriteLine();
            Console.WriteLine("Valor Reais: " +valorReais.ToString ("R$ #,##0.00"));
            Console.ReadLine();
        }
    }
}
