﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace contagem
{
    class Program
    {
        static void Main(string[] args)
        {
            int v, t;
            t = 1;

                while (t <= 9)
                {
                    Console.WriteLine(t);

                    v = 0;
                    while (v <= 9)
                        {
                            Console.Write(v);
                            v=v+1;
                        }

                    Console.WriteLine();
                    t=t+1;
                }
            Console.WriteLine("Pressione 'Enter' para fechar o programa!");
            Console.ReadLine();
        }
    }
}
