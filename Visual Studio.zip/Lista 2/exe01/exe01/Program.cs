﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exe01
{
    class Program
    {
        static void Main(string[] args)
        {
            float x;
            string nome;

            Console.Write("Digite seu nome: ");
            nome = Console.ReadLine();
            Console.WriteLine("Olá, " + nome);
            Console.Write("Digite um número: ");
            x = float.Parse(Console.ReadLine());

            if (x < 0)
            {
                Console.WriteLine("Negativo");
            }
            else
            {

                if (x > 0)
                {
                    Console.WriteLine("Positivo");
                }
                else
                {

                    if (x == 0)
                    {
                        Console.WriteLine("Zero");
                    }
                }
            }
        }
    }
}