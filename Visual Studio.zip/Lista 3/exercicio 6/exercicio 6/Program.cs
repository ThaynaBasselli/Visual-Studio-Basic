﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, x, soma;
            soma = 0;
            for (i = 1; i <= 10; i++) 
            {
                Console.Write("Digite o valor " + i + " : ");
                x = int.Parse(Console.ReadLine());
                soma = soma + x;

            }
            Console.WriteLine("Soma dos numeros = " + soma);
            Console.ReadLine();
        }
    }
}
