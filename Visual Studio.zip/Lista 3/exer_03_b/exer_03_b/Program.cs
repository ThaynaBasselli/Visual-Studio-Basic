﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer_03_b
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            for(i = 101; i => 110; i++)
            {
                Console.WriteLine(i);
            }
                Console.ReadLine();
        }
    }
}
