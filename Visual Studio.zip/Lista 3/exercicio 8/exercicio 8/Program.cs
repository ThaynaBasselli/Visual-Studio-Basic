﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int y, i, num;
            Console.Write("Digite um numero qualquer : ");
            num = int.Parse(Console.ReadLine());
            i = 1;
            y = 0;
            while ( i < num)
            {
                if (num % 1 == 0)
                    y = y + 1;
                i = i + 1;
                
            }
            if (num == y)
                Console.WriteLine(num + " é um número perfeito :");
            else
                Console.WriteLine(num + "Não é um número perfeito  ");
            Console.ReadLine();
        }  

    }
}
