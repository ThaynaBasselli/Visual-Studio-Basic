﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_7
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            i = 1000;

            while (i >= 1)
            {
                if (i % 7 == 0)
                    Console.WriteLine(i + " é multiplo de 7 ");
                i--;

            }
            Console.ReadLine();

        }
    }
}
