﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer_04_a
{
    class Program
    {
        static void Main(string[] args)
        {
            Int a, z;
            Console.writeline(“Escolha um número! ”);
            a = int.Parse(Console.ReadLine);
            z = 1;
            For(z = 1; z => 10; z++)
            {
                Consoloe.Writeline(a + “vezes” +z + “=” +a * z);
            }
            Console.Readline();

        }
    }
}
