﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer_02_b
{
    class Program
    {
        static void Main(string[] args)
        {
            //Imprimir números de 1 a 10 na ordem decrescente

            int i;
            for(i = 10; i => 1; i--)
            {
                Console.WriteLine(i);
            }
                Console.ReadLine();
        }
    }
}
