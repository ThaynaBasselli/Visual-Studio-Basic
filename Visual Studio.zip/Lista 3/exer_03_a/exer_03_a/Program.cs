﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer_03_a
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            int = 101;

           while(i <= 110)
            {
                Console.WriteLine(i);
                i = i + 1;
            }
                Console.ReadLine();
        }
    }
}
