﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer_02_a
{
    class Program
    {
        static void Main(string[] args)
        {
            //Imprimir números de 1 a 10 na ordem decrescente

            int i;
            int i = 10;

            while(i >= 1)
            {
                Console.WriteLine(i);
                i = i - 1;
            }
                Console.ReadLine();
        }
    }
}
