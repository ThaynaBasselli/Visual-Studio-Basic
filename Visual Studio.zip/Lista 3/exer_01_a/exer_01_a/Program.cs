﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exer_01_a
{
    class Program
    {
        static void Main(string[] args)
        {
          //Imprimir números de 1 a 10 ordem crescente

            int i;
            i = 1;

            while(i <= 10)
            {
                Console.WriteLine(i);
                i = i + 1;
            }
                Console.ReadLine();
        }
    }
}
