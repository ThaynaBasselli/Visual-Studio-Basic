﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exerc_08
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercício 8 - 
        }
    }
}
