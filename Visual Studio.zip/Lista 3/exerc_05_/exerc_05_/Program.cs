﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exerc_05_
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ler 5 valores e exibir quantos são positivos e quantos negativos
            int i, a, pos, neg;
            pos = 0;
            neg = 0;
            i = 1;

            while(i <= 5)
            {
                Console.Write(“Informe Valor: ”);
                a = int.Parse(Console.ReadLine());

                if(a >= 0)
                    pos = pos + 1;
                else
                    neg = neg + 1;
                    i = i + 1;
            }
            Console.WriteLine(pos + “número positivo e ” +neg + “ número negativo.” );
        }
    }
}
