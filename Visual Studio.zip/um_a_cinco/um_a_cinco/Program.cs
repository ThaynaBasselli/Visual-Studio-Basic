﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace um_a_cinco
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            x = 0;
                while (x <= 0 || x >= 6)
                {
                    Console.Write("Digite um numero de 1 a 5: ");
                    x = int.Parse(Console.ReadLine());

                    if (x <= 0 || x >=6 )
                    {
                        Console.Write("Valor inválido, digite 'Enter' para continuar");
                        Console.ReadLine();
                        Console.Clear();
                    }

                }
        }
    }
}
