﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace urna
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcao;
            int cand33 = 0, cand44 = 0, cand55 = 0, cand77 = 0, cand88 = 0;
            opcao = 0;
            int voto = 0;
            while (opcao <= 0 || opcao >= 4) // || operador OU
            {
                Console.WriteLine("*** URNA ELETRONICA ***");
                Console.WriteLine();
                Console.WriteLine("1 - VOLTAR");
                Console.WriteLine("2 - RELATÓRIO");
                Console.WriteLine("3 - FIM");
                Console.WriteLine();
                Console.Write("Qual a sua opção: ");
                opcao = int.Parse(Console.ReadLine());
                if (opcao <= 0 || opcao >= 4)
                {
                    Console.Write("Opção Inválida! Tente Novamente, <ENTER> para continuar.");
                    Console.ReadLine(); // faz pausa
                    Console.Clear(); //Limpa a tela
                }
                if (opcao == 3)
                    break; //Finaliza o programa
                else if (opcao == 1)
                {
                    string resp;
                    resp = "n";
                    while (resp != "s")
                    {
                        // Menu de Candidato
                        int voto = 0;
                        Console.Clear();
                        Console.WriteLine("*** URNA ELETRÔNICA ***");
                        Console.WriteLine();
                        Console.WriteLine("33 - Macaco Tião");
                        Console.WriteLine("44 - Urso Panda");
                        Console.WriteLine("55 - Mico Leão");
                        Console.WriteLine("77 - Branco");
                        Console.WriteLine("88 - Nulo");
                        Console.WriteLine();
                        Console.Write("Digite seu voto: ");
                        voto = int.Parse(Console.ReadLine());
                        Console.WriteLine("=======================");
                        if (voto == 33)
                            Console.WriteLine("SEU VOTO É: MACACO TIÃO");
                        else if (voto == 44)
                            Console.WriteLine("SEU VOTO É: URSO PANDA");
                        else if (voto == 55)
                            Console.WriteLine("SEU VOTO É: MICO LEÃO");
                        else if (voto == 77)
                            Console.WriteLine("SEU VOTO É: BRANCO");
                        else
                            Console.WriteLine("SEU VOTO É: NULO");
                        Console.WriteLine("=================================");
                        Console.Write("Confirma o seu voto (S/N) ");
                        resp = Console.ReadLine();
                    }
                    Console.Clear();
                    opcao = 0;
                    if (resp == "s")
                    {
                        if (voto == 33)
                            cand33++;
                        else if (voto == 44)
                            cand44++;
                        else if (voto == 55)
                            cand55++;
                        else if (voto == 77)
                            cand77++;
                        else
                            cand88++;
                    }
                }
                else if (opcao == 2)
                {
                    //Menu de Relatório
                    Console.Clear();
                    Console.WriteLine("============================");
                    Console.WriteLine("*** ELEIÇÕES - APURAÇÃO ***");
                    Console.WriteLine("============================");
                    Console.WriteLine("MACACO TIÃO........."+cand33);
                    Console.WriteLine("URSO PANDA.........."+cand44);
                    Console.WriteLine("MICO LEÃO..........."+cand55);
                    Console.WriteLine("BRANCO.............."+cand77);
                    Console.WriteLine("NULO................"+cand88);
                    Console.WriteLine("============================");
                    int todosvotos = 0;
                }
            }
         
        }
    }
}
